# Yuliia Shtefan — Portfolio

A static portfolio site with a **local visual editor**, split so that only the
finished site is ever public — the content, image originals, and the editor
itself stay private to you.

## Why it's split this way

A plain static host (including GitHub Pages serving a repo directly) can only
do one thing: publish whatever files you give it, verbatim, to anyone who
asks. There's no way to host *part* of a repo publicly and keep the rest
private — "private repo" only hides the repo page on github.com, not the
live site's files. So the only real fix is to **never give the host anything
but the finished pages**:

```
content/site.json   ← all your copy, image paths, structure        PRIVATE
src/render.js         ← turns site.json into HTML                    PRIVATE
admin/                ← the visual editor                            PRIVATE, runs only on your computer
images/               ← original uploads                             PRIVATE
build.mjs             ← compiles the above into dist/                PRIVATE

dist/                 ← the compiled site (HTML/CSS/JS/images only)  PUBLIC — this is the only thing deployed
```

`dist/` is rebuilt from scratch every time (`node build.mjs`) and is the
*only* folder that should ever reach a public host. Nothing else in this
repo needs to, or should, go near the internet.

## Setup — pick one

### Option A: Netlify / Vercel / Cloudflare Pages (recommended, free, least setup)

These connect directly to a **private** GitHub repo, build it on their own
servers, and serve only the output folder you tell them to. Your repo
contents are never exposed — visitors only ever see what's in `dist/`.

1. Push everything in this folder to a new **private** GitHub repository.
2. Create a free account on Netlify, Vercel, or Cloudflare Pages and "import"
   that repository (each walks you through authorizing access to it).
3. Set:
   - **Build command:** `node build.mjs`
   - **Publish / output directory:** `dist`
4. Deploy. You'll get a URL like `your-site.netlify.app` (a custom domain can
   be added later in that host's settings).

### Option B: Stay entirely on GitHub, with two repositories

Keep your real repo private, and use a second, plain public repo that holds
*only* the compiled output — GitHub Actions builds and pushes to it for you.

1. Push this folder to a new **private** repo (e.g. `portfolio-source`).
2. Create a second, **public** repo for the live site — e.g.
   `yourname.github.io` (serves at the root of that domain) or any other
   name (then enable Pages on it: Settings → Pages → Deploy from a branch →
   `main` / `/`).
3. In the **private** repo → Settings → Secrets and variables → Actions, add:
   - `PUBLIC_REPO` — e.g. `yourname/yourname.github.io`
   - `DEPLOY_TOKEN` — a fine-grained token scoped **only** to that public
     repo, with **Contents: Read and write**
     (create at <https://github.com/settings/personal-access-tokens/new>)
4. Push to `main`. The included workflow (`.github/workflows/deploy.yml`)
   builds `dist/` and pushes it to the public repo automatically. Check the
   **Actions** tab for progress; the live site updates a minute or two later.

Either way: the public repo/host only ever sees `dist/` — never
`content/site.json`, `src/`, `admin/`, or your original images.

## Editing — always local

The editor lives in `admin/` and is meant to run **on your own computer**,
never deployed anywhere — that's what keeps it private without needing a
password or login. It commits straight to your private source repo.

```bash
npm run admin          # or: python3 -m http.server 8000
# open http://localhost:8000/admin/
```

**One-time connection:** click **GitHub** in the editor, paste in a
fine-grained token scoped to your *private source* repo with **Contents:
Read and write** (<https://github.com/settings/personal-access-tokens/new>).
The token stays in your browser's local storage only.

**Day to day:**
* Click any text in the preview to type over it; click any image to replace it.
* Use the left panel to add/remove/reorder projects, expertise items, social
  links, paragraphs, and image rows.
* **Publish** commits your changes (just `content/site.json` plus any newly
  uploaded images) to the private repo. Your build (Option A or B above)
  then regenerates `dist/` and the live site updates automatically — the
  editor itself never talks to your live host directly.

## Editing without the editor

```bash
node build.mjs                 # regenerate dist/ from content/site.json
npm run preview                 # build, then serve dist/ at http://localhost:8000
```

Edit `content/site.json` by hand, or change `css/style.css` for design, or
`src/render.js` for structure — then rebuild.

## Good to know

* **The editor is local-only on purpose.** If you ever do want to edit from
  another device, run it there too (same repo, same token) rather than
  hosting `admin/` publicly — hosting it would undo the whole point of this
  setup.
* **`dist/` is git-ignored** in this repo — Option A's host builds it fresh
  on their servers each deploy; Option B's Action builds it fresh each push.
  You never need to commit it yourself.
* **Placeholder images** (`images/placeholders/`) ship with the project;
  replace them from the editor.
* **Fonts** (Playfair Display, Inter) load from Google Fonts at view time —
  no font files are needed in `dist/`.
* **Edit from one place at a time.** The editor loads the latest
  `content/site.json` from GitHub when it opens; if you edit on two devices
  without reloading in between, the later Publish wins and can overwrite the
  earlier one.

## Troubleshooting

| Message | Fix |
|---|---|
| "GitHub rejected the token" | Token mistyped or expired — create a new one. |
| "The token isn't allowed to do that" | Token needs **Contents: Read and write** on the private source repo. |
| "Repository or branch not found" | Check owner/repo/branch spelling, and that the token covers this repo. |
| Published but the live site looks unchanged | Check your host's build log (Option A: its dashboard; Option B: the **Actions** tab) — the build runs after you publish, not instantly. |
| "Couldn't load content/site.json" | Open the editor via `http://localhost:8000/admin/`, not by double-clicking the file. |
